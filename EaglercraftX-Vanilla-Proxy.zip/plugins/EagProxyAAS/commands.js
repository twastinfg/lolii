const PluginManager = PLUGIN_MANAGER;
const Logger = PluginManager.Logger;
const Enums = PluginManager.Enums;
const Chat = PluginManager.Chat;
const Constants = PluginManager.Constants;
const Motd = PluginManager.Motd;
const Player = PluginManager.Player;
const MineProtocol = PluginManager.MineProtocol;
const EaglerSkins = PluginManager.EaglerSkins;
const Util = PluginManager.Util;
export function processCommand(cmdStr, executor) {
    if (cmdStr.startsWith('/eag-switchservers')) {
    }
}
export function switchServers(player) {
}
export function toggleParticles(player) {
}
