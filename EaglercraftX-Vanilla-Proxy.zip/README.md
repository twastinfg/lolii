# EaglerProxy as a Service
**THIS PROXY IS ONLY SUITABLE FOR EAGLERCRAFTX VERSIONS u15 AND u16. OLDER AND NEWER VERSIONS MAY NOT CONNECT OR OPTIMALLY FUNCTION.**  
**Note: The `launcher_accounts.json` is automatically created by a Node.js module being used. Do not worry about it, no actual user credentials are being saved.**
An EaglercraftX-to-1.8.9 proxy. Allows EaglercraftX clients to connect to any online 1.8.9 server of their choosing.
## Disclaimer
## **DO NOT JOIN HYPIXEL FROM THIS PROXY AND FROM YOUR HOME INTERNET IN QUICK SUCCESSION! YOU WILL GET SECURITY BANNED!**

This proxy requires you to log in via Microsoft with an account with Minecraft: Java Edition ownership to obtain necessary Minecraft session tokens to connect to online game servers. For security reasons, no login data is saved nor captured, and this repo's source code is available to the public. Please be careful when using forks of this project, as they may contain edits to the source code used to capture session tokens and use them for malicious purposes.

In addition, there is no 100% guarantee that EaglercraftX is completely safe for use on vanilla game servers. While initial testing on the proxy has returned positive results, there still exists a possibiltity of the game accidentally tripping a server's anticheat and getting you banned. You have been warned.

TL;DR: You need to log in with a Microsoft account with Minecraft on it. Do not enter any account credentials on any forked repls of this repl you do not trust. Also, you might trigger some anticheats and get banned, although the probability of this happening is very low.
## How to Play
1. Connect to the proxy server.
2. Log in via Microsoft.
3. Join any server of your choice by running `/join <server> <ip>`.
4. Have fun!